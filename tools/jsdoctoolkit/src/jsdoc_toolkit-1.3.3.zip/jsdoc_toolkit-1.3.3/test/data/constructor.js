﻿/**
 * Constructor with no parameters.
 * @class A collection of records.
 * @constructor
 */

/**
 * Constructor with a foo parameter.
 * @name RecordSet
 * @constructor
 * @param foo
 */
function RecordSet() {
}
