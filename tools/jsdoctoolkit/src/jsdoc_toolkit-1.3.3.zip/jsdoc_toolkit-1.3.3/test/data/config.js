/**
 * @constructor
 * @param person The person.
 * @config {string} name The person's name.
 * @config {integer} age The person's age.
 * @param [id] Optional id number to use.
 */
function Contact(person, id) {

}

/**
 * @constructor
 * @config {string} Father The paternal person.
 * @config {string} Mother The maternal person.
 * @config {string[]} Children And the rest.
 */
function Family() {

}
