﻿/** Change the role of the employee. */
function recast(employeeId, newRole) {
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "Change the role of the employee.",
                alias: "recast",
                memberof: "",
                params: [
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "employeeId",
                        isOptional: false
                    },
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "newRole",
                        isOptional: false
                    }
                ],
                methods: [],
                name: "recast"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/functions2.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/functions2.js"
        }
    }
]
*/