﻿record = {
    row: {
         field: {
            /** Remove the record. */
            remove: function() {
            }
        }
    }
};

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "Remove the record.",
                alias: "record.row.field.remove",
                memberof: "",
                params: [],
                methods: [],
                name: "record.row.field.remove"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/nested_function3.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/nested_function3.js"
        }
    }
]
*/