/**
 @namespace Holds all Filebox functionality.
*/
Filebox = {
    lookup: function() {
    },
    add: function() {
    },
    remove: function() {
    }
}