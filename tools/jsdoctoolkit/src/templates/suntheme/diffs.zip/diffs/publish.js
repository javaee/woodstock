72,81c72
< 
<         // Don't show private classes in index template unless -p option is used.
<         if (JsDoc.opt.p != true) {
<             for (var c in allClasses) {
<                 if (c.indexOf("._") != -1) {
<                     delete(allClasses[c]);
<                 }
<             }
<         }
< 
---
> 	
106c97
< }
---
> }
