/**
 @namespace Holds all Filebox functionality.
*/
Filebox.View = {
    lookup: function() {
    },
    add: function() {
    }
}

/**
 Change the order of the files.
 */
Filebox.View.reorder = function() {

};