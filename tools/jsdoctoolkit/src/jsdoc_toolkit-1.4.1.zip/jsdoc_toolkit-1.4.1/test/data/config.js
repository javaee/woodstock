/**
 * @constructor
 * @param person The person.
 * @config {string} name The person's name.
 * @config {integer} age The person's age.
 * @config [id] Optional id number to use.
 * @param connection
 */
function Contact(person, connection) {

}

/**
 * @constructor
 * @config {string} Father The paternal person.
 * @config {string} Mother The maternal person.
 * @config {string[]} Children And the rest.
 */
function Family() {

}
