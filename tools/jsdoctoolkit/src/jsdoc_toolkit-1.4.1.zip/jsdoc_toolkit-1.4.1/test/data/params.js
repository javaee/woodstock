
/**
 * @param { String ,    Array } [id] Specifies the id, if applicable.
 */
function Document(id){

	this.publish = function(
		source,
		format,
		target
	)
	{}

}


/**
 * @param tag {String} Specifies the id, if applicable.
 */
function Paragraph(id){

}
