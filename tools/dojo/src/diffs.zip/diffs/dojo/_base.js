2c2
< dojo.require("dojo._base.lang"); // Woodstock: Unused.
---
> dojo.require("dojo._base.lang");
5,8c5,8
< //dojo.require("dojo._base.Deferred"); // Woodstock: Unused.
< //dojo.require("dojo._base.json"); // Woodstock: Unused.
< dojo.require("dojo._base.array"); // Woodstock: Unused.
< //dojo.require("dojo._base.Color"); // Woodstock: Unused.
---
> dojo.require("dojo._base.Deferred");
> dojo.require("dojo._base.json");
> dojo.require("dojo._base.array");
> dojo.require("dojo._base.Color");
12,15c12,15
< //dojo.requireIf(dojo.isBrowser, "dojo._base.NodeList"); // Woodstock: Unused.
< dojo.requireIf(dojo.isBrowser, "dojo._base.query"); // Woodstock: Unused.
< //dojo.requireIf(dojo.isBrowser, "dojo._base.xhr"); // Woodstock: Unused.
< //dojo.requireIf(dojo.isBrowser, "dojo._base.fx"); // Woodstock: Unused.
---
> dojo.requireIf(dojo.isBrowser, "dojo._base.NodeList");
> dojo.requireIf(dojo.isBrowser, "dojo._base.query");
> dojo.requireIf(dojo.isBrowser, "dojo._base.xhr");
> dojo.requireIf(dojo.isBrowser, "dojo._base.fx");
