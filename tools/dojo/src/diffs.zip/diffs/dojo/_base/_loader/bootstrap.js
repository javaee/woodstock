21c21
< 	if(typeof this.djConfig == "undefined"){ // Woodstock: Modified for custom name space.
---
> 	if(typeof this["djConfig"] == "undefined"){
43,44c43,44
< 	// dojo is the root variable of (almost all) our public symbols -- make sure it is defined.	
< 	if(typeof this.dojo == "undefined"){ // Woodstock: Modified for custom name space.
---
> 	// dojo is the root variable of (almost all) our public symbols -- make sure it is defined.
> 	if(typeof this["dojo"] == "undefined"){
