11,36d10
< // Woodstock: The baseUrl property is used instead script tag.
< //		// grab the node we were loaded from
< //		if(document && document.getElementsByTagName){
< //			var scripts = document.getElementsByTagName("script");
< //			var rePkg = /dojo(\.xd)?\.js([\?\.]|$)/i;
< //			for(var i = 0; i < scripts.length; i++){
< //				var src = scripts[i].getAttribute("src");
< //				if(!src){ continue; }
< //				var m = src.match(rePkg);
< //				if(m){
< //					// find out where we came from
< //					if(!djConfig["baseUrl"]){
< //						djConfig["baseUrl"] = src.substring(0, m.index);
< //					}
< //					// and find out if we need to modify our behavior
< //					var cfg = scripts[i].getAttribute("djConfig");
< //					if(cfg){
< //						var cfgo = eval("({ "+cfg+" })");
< //						for(var x in cfgo){
< //							djConfig[x] = cfgo[x];
< //						}
< //					}
< //					break; // "first Dojo wins"
< //				}
< //			}
< //		}
38,40c12,35
< 		// Woodstock: Append slash typically left by parsing script tag.
<                 if (djConfig["baseUrl"].charAt(djConfig["baseUrl"].length) != '/') {
< 			djConfig["baseUrl"] += "/";
---
> 		// grab the node we were loaded from
> 		if(document && document.getElementsByTagName){
> 			var scripts = document.getElementsByTagName("script");
> 			var rePkg = /dojo(\.xd)?\.js([\?\.]|$)/i;
> 			for(var i = 0; i < scripts.length; i++){
> 				var src = scripts[i].getAttribute("src");
> 				if(!src){ continue; }
> 				var m = src.match(rePkg);
> 				if(m){
> 					// find out where we came from
> 					if(!djConfig["baseUrl"]){
> 						djConfig["baseUrl"] = src.substring(0, m.index);
> 					}
> 					// and find out if we need to modify our behavior
> 					var cfg = scripts[i].getAttribute("djConfig");
> 					if(cfg){
> 						var cfgo = eval("({ "+cfg+" })");
> 						for(var x in cfgo){
> 							djConfig[x] = cfgo[x];
> 						}
> 					}
> 					break; // "first Dojo wins"
> 				}
> 			}
