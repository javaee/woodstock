16,19c16,18
< 			// Woodstock: Added quotes around keys to support dot syntax.
< 			"dojo": {name: "dojo", value: "."},
< 			"doh": {name: "doh", value: "../util/doh"},
< 			"tests": {name: "tests", value: "tests"}
---
> 			dojo: {name: "dojo", value: "."},
> 			doh: {name: "doh", value: "../util/doh"},
> 			tests: {name: "tests", value: "tests"}
