9,11d8
<         // Woodstock: Path must not be modified by custom build.
<         var prefix = "_do" + "jo";
< 
17c14
< 		// FIXME: it should be possible to pull module prefixes in from djConfig               
---
> 		// FIXME: it should be possible to pull module prefixes in from djConfig
19,22c16,18
< 			// Woodstock: Added quotes around keys to support dot syntax.
< 			"dojo": {name: "dojo", value: prefix},
< 			"doh": {name: "doh", value: prefix + "/util/doh"},
< 			"tests": {name: "tests", value: prefix + "/tests"}
---
> 			dojo: {name: "dojo", value: "."},
> 			doh: {name: "doh", value: "../util/doh"},
> 			tests: {name: "tests", value: "tests"}
