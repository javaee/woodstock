6c6
< //dojo.require("dojo.parser"); // Woodstock: Unused.
---
> dojo.require("dojo.parser");
282,284c282
< 
<                         // Woodstock: IE throws security exception here.
< 			//dojo.body().appendChild(tn);
---
> 			dojo.body().appendChild(tn);
302,305d299
<                 // Woodstock: If "tn" is appended before text is added, IE
<                 // throws security exception.
<                 dojo.body().appendChild(tn);
< 
316,320d309
< 
<                 // Woodstock: IE throws security exception if "tn" isn't removed.
<                 // This allows widgets to be created before the window onLoad event.
<                 dojo.body().removeChild(tn);
< 
