3c3
< //dojo.require("dijit._base.focus"); // Woodstock: Unused.
---
> dojo.require("dijit._base.focus");
5,7c5,7
< //dojo.require("dijit._base.place"); // Woodstock: Unused.
< //dojo.require("dijit._base.popup"); // Woodstock: Unused.
< //dojo.require("dijit._base.scroll"); // Woodstock: Unused.
---
> dojo.require("dijit._base.place");
> dojo.require("dijit._base.popup");
> dojo.require("dijit._base.scroll");
9,12c9,12
< //dojo.require("dijit._base.bidi"); // Woodstock: Unused.
< //dojo.require("dijit._base.typematic"); // Woodstock: Unused.
< //dojo.require("dijit._base.wai");
< //dojo.require("dijit._base.window"); // Woodstock: Unused.
---
> dojo.require("dijit._base.bidi");
> dojo.require("dijit._base.typematic");
> dojo.require("dijit._base.wai");
> dojo.require("dijit._base.window");
