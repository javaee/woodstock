14c14
< 	id: null, // Woodstock: Set null for issue #975
---
> 	id: "",
19c19
< 	lang: null, // Woodstock: Set null for issue #975
---
> 	lang: "",
23c23
< 	dir: null, // Woodstock: Set null for issue #975
---
> 	dir: "",
27c27
< 	"class": null, // Woodstock: Set null for issue #975
---
> 	"class": "",
31c31
< 	style: null, // Woodstock: Set null for issue #975
---
> 	style: "",
35c35
< 	title: null, // Woodstock: Set null for issue #975
---
> 	title: "",
