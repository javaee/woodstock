if(!dojo._hasResource["dijit.tests.widgetsInTemplate"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests.widgetsInTemplate"] = true;
dojo.provide("dijit.tests.widgetsInTemplate");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.widgetsInTemplate", dojo.moduleUrl("dijit", "tests/widgetsInTemplate.html"));
}

}
