if(!dojo._hasResource["dojox.crypto"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.crypto"] = true;
dojo.provide("dojox.crypto");
dojo.require("dojox.crypto._base");

}
