if(!dojo._hasResource["dojox.collections"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.collections"] = true;
dojo.provide("dojox.collections");
dojo.require("dojox.collections._base");

}
