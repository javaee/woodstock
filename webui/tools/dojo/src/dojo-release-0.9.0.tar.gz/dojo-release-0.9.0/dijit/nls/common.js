({
	buttonOk: "OK",
	buttonCancel: "Cancel",
	buttonSave: "Save"
})
